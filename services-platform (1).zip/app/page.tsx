"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Search, Phone, Globe, LogOut, Settings, ArrowLeft } from "lucide-react"
import { useAdmin } from "@/contexts/admin-context"
import { useRouter } from "next/navigation"

interface SubService {
  id: string
  name: string
  emoji: string
}

interface ServiceCategory {
  id: string
  name: string
  emoji: string
  subServices: SubService[]
}

const defaultCategories: ServiceCategory[] = [
  {
    id: "electrician",
    name: "Electrician",
    emoji: "⚡",
    subServices: [
      { id: "wiring", name: "Wiring Installation", emoji: "🔌" },
      { id: "switch-repair", name: "Switch/Socket Repair", emoji: "🔧" },
      { id: "fan-install", name: "Fan Installation", emoji: "🌀" },
      { id: "light-install", name: "Light Installation", emoji: "💡" },
      { id: "ups-wiring", name: "UPS Wiring", emoji: "🔋" },
      { id: "circuit-breaker", name: "Circuit Breaker Replacement", emoji: "⚡" },
      { id: "inverter-install", name: "Inverter Installation", emoji: "🔌" },
    ],
  },
  {
    id: "car-mechanic",
    name: "Car Mechanic",
    emoji: "🚗",
    subServices: [
      { id: "oil-change", name: "Oil Change", emoji: "🛢️" },
      { id: "tire-service", name: "Tire Service", emoji: "🛞" },
      { id: "engine-tuning", name: "Engine Tuning", emoji: "⚙️" },
      { id: "car-ac-repair", name: "Car AC Repair", emoji: "❄️" },
      { id: "battery-replacement", name: "Battery Replacement", emoji: "🔋" },
      { id: "car-electrician", name: "Car Electrician", emoji: "⚡" },
      { id: "denting-painting", name: "Denting & Painting", emoji: "🔨" },
      { id: "auto-painter", name: "Auto Painter", emoji: "🎨" },
      { id: "tow-truck", name: "Tow Truck Service", emoji: "🚛" },
    ],
  },
  {
    id: "cook-kitchen",
    name: "Cook / Kitchen Help",
    emoji: "🍳",
    subServices: [
      { id: "home-cook", name: "Home Cook", emoji: "👨‍🍳" },
      { id: "event-cook", name: "Event Cook", emoji: "🍽️" },
      { id: "chef-demand", name: "Chef on Demand", emoji: "👨‍🍳" },
    ],
  },
  {
    id: "babysitter-nanny",
    name: "Babysitter / Nanny / Caretaker",
    emoji: "👶",
    subServices: [
      { id: "babysitting", name: "Babysitting", emoji: "👶" },
      { id: "fulltime-nanny", name: "Full-time Nanny", emoji: "👩‍👧" },
      { id: "elderly-caretaker", name: "Elderly Caretaker", emoji: "🤝" },
    ],
  },
  {
    id: "cleaning-laundry",
    name: "Cleaning & Laundry",
    emoji: "🧺",
    subServices: [
      { id: "home-cleaning", name: "Home Cleaning", emoji: "🧹" },
      { id: "office-cleaning", name: "Office Cleaning", emoji: "🏢" },
      { id: "sofa-carpet", name: "Sofa/Carpet Cleaning", emoji: "🛋️" },
      { id: "laundry-service", name: "Laundry Service", emoji: "👕" },
    ],
  },
  {
    id: "salon-beauty",
    name: "Salon & Beauty",
    emoji: "💇",
    subServices: [
      { id: "barber", name: "Barber", emoji: "💇‍♂️" },
      { id: "hair-stylist", name: "Hair Stylist", emoji: "💇‍♀️" },
      { id: "makeup-artist", name: "Makeup Artist", emoji: "💄" },
      { id: "personal-grooming", name: "Personal Grooming", emoji: "✨" },
    ],
  },
  {
    id: "painter",
    name: "Painter",
    emoji: "🎨",
    subServices: [
      { id: "wall-painting", name: "Wall Painting", emoji: "🖌️" },
      { id: "furniture-painting", name: "Furniture Painting", emoji: "🪑" },
      { id: "house-interior", name: "House Interior/Exterior Painting", emoji: "🏠" },
    ],
  },
  {
    id: "carpenter",
    name: "Carpenter",
    emoji: "🪚",
    subServices: [
      { id: "furniture-repair", name: "Furniture Repair", emoji: "🔨" },
      { id: "door-window", name: "Door/Window Fixing", emoji: "🚪" },
      { id: "custom-woodwork", name: "Custom Woodwork", emoji: "🪵" },
    ],
  },
  {
    id: "delivery-driver",
    name: "Delivery Boy / Driver",
    emoji: "🚚",
    subServices: [
      { id: "car-driver", name: "Car Driver", emoji: "🚙" },
      { id: "bike-rider", name: "Bike Rider", emoji: "🏍️" },
      { id: "parcel-delivery", name: "Parcel Delivery", emoji: "📦" },
    ],
  },
  {
    id: "appliance-repair",
    name: "Appliance Repair",
    emoji: "🛠️",
    subServices: [
      { id: "refrigerator-repair", name: "Refrigerator Repair", emoji: "❄️" },
      { id: "washing-machine", name: "Washing Machine Repair", emoji: "🌀" },
      { id: "microwave-repair", name: "Microwave Repair", emoji: "📱" },
      { id: "mobile-repair", name: "Mobile Repair", emoji: "📱" },
      { id: "laptop-repair", name: "Laptop Repair", emoji: "💻" },
      { id: "computer-tech", name: "Computer Technician", emoji: "🖥️" },
    ],
  },
  {
    id: "cctv-it",
    name: "CCTV & IT",
    emoji: "📹",
    subServices: [
      { id: "cctv-installation", name: "CCTV Installation", emoji: "📹" },
      { id: "cctv-monitoring", name: "CCTV Monitoring", emoji: "👁️" },
      { id: "it-support", name: "IT Support", emoji: "💻" },
      { id: "computer-networking", name: "Computer Networking", emoji: "🌐" },
    ],
  },
  {
    id: "generator-repair",
    name: "Generator Repair",
    emoji: "🔧",
    subServices: [
      { id: "generator-maintenance", name: "General Generator Maintenance", emoji: "⚙️" },
      { id: "generator-installation", name: "Generator Installation", emoji: "🔌" },
    ],
  },
  {
    id: "security-services",
    name: "Security Services",
    emoji: "🛡️",
    subServices: [
      { id: "security-guard", name: "Security Guard", emoji: "🛡️" },
      { id: "bodyguard", name: "Bodyguard", emoji: "🕴️" },
      { id: "watchman", name: "Watchman", emoji: "👮" },
      { id: "bouncer", name: "Bouncer", emoji: "💪" },
    ],
  },
  {
    id: "event-management",
    name: "Event Management",
    emoji: "🎉",
    subServices: [
      { id: "event-planner", name: "Event Planner", emoji: "🎉" },
      { id: "wedding-planner", name: "Wedding Planner", emoji: "💒" },
      { id: "caterer", name: "Caterer", emoji: "🍽️" },
      { id: "dj-music", name: "DJ / Music Band", emoji: "🎧" },
      { id: "stage-decoration", name: "Stage Decoration", emoji: "🎭" },
      { id: "flower-decoration", name: "Flower Decoration", emoji: "🌸" },
      { id: "sound-system", name: "Sound System Provider", emoji: "🔊" },
      { id: "photographer", name: "Photographer (Event)", emoji: "📸" },
      { id: "videographer", name: "Videographer (Event)", emoji: "🎥" },
    ],
  },
  {
    id: "health-fitness",
    name: "Health & Fitness",
    emoji: "🩺",
    subServices: [
      { id: "nurse", name: "Nurse", emoji: "👩‍⚕️" },
      { id: "doctor-call", name: "Doctor on Call", emoji: "👨‍⚕️" },
      { id: "physiotherapist", name: "Physiotherapist", emoji: "🏥" },
      { id: "dietitian", name: "Dietitian", emoji: "🥗" },
      { id: "yoga-trainer", name: "Yoga Trainer", emoji: "🧘" },
      { id: "massage-therapist", name: "Massage Therapist", emoji: "💆" },
      { id: "first-aid", name: "First Aid Service", emoji: "🚑" },
      { id: "personal-trainer", name: "Personal Trainer", emoji: "💪" },
    ],
  },
]

const ITEMS_PER_PAGE = 6

export default function ServicesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(0)
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory | null>(null)
  const [categories, setCategories] = useState(defaultCategories)
  const [appSettings, setAppSettings] = useState({
    whatsappNumber: "03140874932",
    callNumber: "03140874932",
    siteName: "fixy.live",
  })

  const { isAdmin, login, logout } = useAdmin()
  const router = useRouter()

  useEffect(() => {
    const savedCategories = localStorage.getItem("categories-data")
    if (savedCategories) {
      setCategories(JSON.parse(savedCategories))
    }

    const savedSettings = localStorage.getItem("app-settings")
    if (savedSettings) {
      setAppSettings(JSON.parse(savedSettings))
    }
  }, [])

  const filteredItems = useMemo(() => {
    if (selectedCategory) {
      // Filter sub-services within selected category
      if (!searchTerm.trim()) return selectedCategory.subServices
      return selectedCategory.subServices.filter((subService) =>
        subService.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    } else {
      // Filter categories
      if (!searchTerm.trim()) return categories
      return categories.filter(
        (category) =>
          category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          category.subServices.some((subService) => subService.name.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }
  }, [searchTerm, categories, selectedCategory])

  // Calculate pagination
  const totalPages = Math.ceil(filteredItems.length / ITEMS_PER_PAGE)
  const currentItems = filteredItems.slice(currentPage * ITEMS_PER_PAGE, (currentPage + 1) * ITEMS_PER_PAGE)

  // Reset to first page when search changes
  const handleSearchChange = (value: string) => {
    setSearchTerm(value)
    setCurrentPage(0)
  }

  const handleBookNow = (itemName: string) => {
    const message = `Hi, I want ${itemName.toLowerCase()} services. Are you available?`
    const whatsappUrl = `https://wa.me/${appSettings.whatsappNumber}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  const handleCallNow = () => {
    window.open(`tel:${appSettings.callNumber}`, "_self")
  }

  const handleCategoryClick = (category: ServiceCategory) => {
    setSelectedCategory(category)
    setCurrentPage(0)
    setSearchTerm("")
  }

  const handleBackToCategories = () => {
    setSelectedCategory(null)
    setCurrentPage(0)
    setSearchTerm("")
  }

  const handleAdminLogin = () => {
    // Implement admin login logic here
    if (adminPassword === "admin") {
      login()
      setShowAdminLogin(false)
      setAdminPassword("")
    } else {
      alert("Incorrect password")
    }
  }

  const handleAdminLogout = () => {
    logout()
  }

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString("en-US", {
      hour12: true,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-200 via-purple-200 to-pink-200 relative">
      <div className="relative z-10 p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            {selectedCategory && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleBackToCategories}
                className="mr-3 hover:bg-black/20 drop-shadow-sm"
                style={{ color: "#1e3a8a" }}
              >
                <ArrowLeft className="h-6 w-6" />
              </Button>
            )}
            <div>
              <h1 className="text-3xl font-bold text-navy-900 mb-2" style={{ color: "#1e3a8a" }}>
                {selectedCategory ? selectedCategory.name : `Welcome to ${appSettings.siteName}`}
              </h1>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {isAdmin ? (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="hover:bg-black/20 drop-shadow-sm"
                  style={{ color: "#1e3a8a" }}
                  onClick={() => router.push("/admin")}
                  title="Admin Panel"
                >
                  <Settings className="h-6 w-6" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="hover:bg-black/20 drop-shadow-sm"
                  style={{ color: "#1e3a8a" }}
                  onClick={handleAdminLogout}
                  title="Logout"
                >
                  <LogOut className="h-6 w-6" />
                </Button>
              </>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                className="hover:bg-black/20 drop-shadow-sm"
                style={{ color: "#1e3a8a" }}
                onClick={() => setShowAdminLogin(true)}
                title="Admin Login"
              >
                <Globe className="h-6 w-6" />
              </Button>
            )}
          </div>
        </div>

        {isAdmin && (
          <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3 mb-6">
            <p className="text-sm font-medium" style={{ color: "#1e3a8a" }}>
              🔐 Admin Mode Active - You can manage services and settings
            </p>
          </div>
        )}

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            type="text"
            placeholder={selectedCategory ? "Search sub-services..." : "Search categories..."}
            value={searchTerm}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-10 bg-white/90 backdrop-blur-sm border-0 text-gray-800 placeholder:text-gray-500"
          />
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {currentItems.map((item) => (
            <Card key={item.id} className="bg-white/95 backdrop-blur-sm border-0 p-4 text-center">
              <div className="text-4xl mb-3">{item.emoji}</div>
              <h3 className="font-semibold text-gray-800 mb-4 text-sm">{item.name}</h3>
              <div className="space-y-2">
                {selectedCategory ? (
                  <>
                    <Button
                      onClick={() => handleBookNow(item.name)}
                      className="w-full bg-green-500 hover:bg-green-600 text-white font-medium py-2 rounded-full"
                    >
                      Book Now
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleCallNow}
                      className="w-full border-gray-300 text-gray-700 hover:bg-gray-50 py-2 rounded-full bg-transparent"
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </Button>
                  </>
                ) : (
                  <Button
                    onClick={() => handleCategoryClick(item as ServiceCategory)}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 rounded-full"
                  >
                    View Services
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center space-x-4 mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
              disabled={currentPage === 0}
              className="bg-white/30 hover:bg-white/50 rounded-xl drop-shadow-sm"
              style={{ color: "#1e3a8a" }}
            >
              ←
            </Button>

            <div className="flex space-x-2">
              {Array.from({ length: totalPages }, (_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentPage(i)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    i === currentPage ? "drop-shadow-sm" : "hover:opacity-80"
                  }`}
                  style={{ backgroundColor: i === currentPage ? "#1e3a8a" : "rgba(30, 58, 138, 0.4)" }}
                />
              ))}
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentPage(Math.min(totalPages - 1, currentPage + 1))}
              disabled={currentPage === totalPages - 1}
              className="bg-white/30 hover:bg-white/50 rounded-xl drop-shadow-sm"
              style={{ color: "#1e3a8a" }}
            >
              →
            </Button>
          </div>
        )}

        {/* Page Info */}
        <div className="text-center text-sm" style={{ color: "#1e3a8a" }}>
          Slide {currentPage + 1} of {totalPages} • {filteredItems.length}{" "}
          {selectedCategory ? "services" : "categories"}
        </div>

        {/* Admin Login Modal */}
        {showAdminLogin && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-md p-6">
              <h2 className="text-xl font-bold mb-4 text-center">Admin Login</h2>
              <div className="space-y-4">
                <Input
                  type="password"
                  placeholder="Enter admin password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleAdminLogin()}
                />
                <div className="flex space-x-2">
                  <Button onClick={handleAdminLogin} className="flex-1">
                    Login
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowAdminLogin(false)
                      setAdminPassword("")
                    }}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
