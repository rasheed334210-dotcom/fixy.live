"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Plus, Edit, Trash2, Save, X } from "lucide-react"
import { useAdmin } from "@/contexts/admin-context"
import { useRouter } from "next/navigation"

interface Service {
  id: string
  name: string
  emoji: string
  category: string
}

interface Settings {
  whatsappNumber: string
  callNumber: string
  siteName: string
}

const categories = [
  "Personal Care",
  "Home Services",
  "Vehicle Services",
  "Security",
  "Construction",
  "Moving",
  "Food",
  "Travel",
  "Cleaning",
  "Repair",
  "Transport",
  "Education",
  "Energy",
  "Care",
  "Delivery",
  "Fashion",
  "Beauty",
  "Fitness",
  "Tech",
  "Vehicle",
  "Events",
  "Health",
]

export default function AdminPanel() {
  const { isAdmin } = useAdmin()
  const router = useRouter()

  const [services, setServices] = useState<Service[]>([])
  const [settings, setSettings] = useState<Settings>({
    whatsappNumber: "03140874932",
    callNumber: "03140874932",
    siteName: "Services.com",
  })

  const [editingService, setEditingService] = useState<Service | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newService, setNewService] = useState({
    name: "",
    emoji: "",
    category: "",
  })

  // Redirect if not admin
  useEffect(() => {
    if (!isAdmin) {
      router.push("/")
    }
  }, [isAdmin, router])

  // Load services from localStorage
  useEffect(() => {
    const savedServices = localStorage.getItem("services-data")
    if (savedServices) {
      setServices(JSON.parse(savedServices))
    } else {
      // Initialize with default services
      const defaultServices = [
        { id: "1", name: "Barber", emoji: "💇‍♂️", category: "Personal Care" },
        { id: "2", name: "LPG Cylinder", emoji: "🔥", category: "Home Services" },
        { id: "3", name: "Auto Washing", emoji: "🚗", category: "Vehicle Services" },
        { id: "4", name: "Parlour", emoji: "💄", category: "Personal Care" },
        { id: "5", name: "AC Installer", emoji: "❄️", category: "Home Services" },
        { id: "6", name: "Gardener", emoji: "🌱", category: "Home Services" },
      ]
      setServices(defaultServices)
      localStorage.setItem("services-data", JSON.stringify(defaultServices))
    }

    const savedSettings = localStorage.getItem("app-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const saveServices = (updatedServices: Service[]) => {
    setServices(updatedServices)
    localStorage.setItem("services-data", JSON.stringify(updatedServices))
  }

  const saveSettings = (updatedSettings: Settings) => {
    setSettings(updatedSettings)
    localStorage.setItem("app-settings", JSON.stringify(updatedSettings))
  }

  const handleAddService = () => {
    if (!newService.name || !newService.emoji || !newService.category) {
      alert("Please fill all fields")
      return
    }

    const service: Service = {
      id: Date.now().toString(),
      name: newService.name,
      emoji: newService.emoji,
      category: newService.category,
    }

    const updatedServices = [...services, service]
    saveServices(updatedServices)
    setNewService({ name: "", emoji: "", category: "" })
    setShowAddForm(false)
  }

  const handleEditService = (service: Service) => {
    setEditingService({ ...service })
  }

  const handleUpdateService = () => {
    if (!editingService) return

    const updatedServices = services.map((service) => (service.id === editingService.id ? editingService : service))
    saveServices(updatedServices)
    setEditingService(null)
  }

  const handleDeleteService = (id: string) => {
    if (confirm("Are you sure you want to delete this service?")) {
      const updatedServices = services.filter((service) => service.id !== id)
      saveServices(updatedServices)
    }
  }

  if (!isAdmin) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-500 to-blue-500 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20"
              onClick={() => router.push("/")}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-white">Admin Panel</h1>
              <p className="text-white/80 text-sm">Manage services and settings</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Settings Panel */}
          <Card className="bg-white/95 backdrop-blur-sm border-0 p-6">
            <h2 className="text-xl font-bold mb-4">Settings</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="siteName">Site Name</Label>
                <Input
                  id="siteName"
                  value={settings.siteName}
                  onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="whatsapp">WhatsApp Number</Label>
                <Input
                  id="whatsapp"
                  value={settings.whatsappNumber}
                  onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="call">Call Number</Label>
                <Input
                  id="call"
                  value={settings.callNumber}
                  onChange={(e) => setSettings({ ...settings, callNumber: e.target.value })}
                />
              </div>
              <Button onClick={() => saveSettings(settings)} className="w-full">
                <Save className="h-4 w-4 mr-2" />
                Save Settings
              </Button>
            </div>
          </Card>

          {/* Add Service Panel */}
          <Card className="bg-white/95 backdrop-blur-sm border-0 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Add Service</h2>
              <Button variant="ghost" size="sm" onClick={() => setShowAddForm(!showAddForm)}>
                {showAddForm ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
              </Button>
            </div>

            {showAddForm && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="serviceName">Service Name</Label>
                  <Input
                    id="serviceName"
                    value={newService.name}
                    onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                    placeholder="e.g., Plumber"
                  />
                </div>
                <div>
                  <Label htmlFor="serviceEmoji">Emoji</Label>
                  <Input
                    id="serviceEmoji"
                    value={newService.emoji}
                    onChange={(e) => setNewService({ ...newService, emoji: e.target.value })}
                    placeholder="e.g., 🔧"
                  />
                </div>
                <div>
                  <Label htmlFor="serviceCategory">Category</Label>
                  <Select
                    value={newService.category}
                    onValueChange={(value) => setNewService({ ...newService, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAddService} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Service
                </Button>
              </div>
            )}
          </Card>

          {/* Statistics */}
          <Card className="bg-white/95 backdrop-blur-sm border-0 p-6">
            <h2 className="text-xl font-bold mb-4">Statistics</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Total Services:</span>
                <span className="font-semibold">{services.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Categories:</span>
                <span className="font-semibold">{new Set(services.map((s) => s.category)).size}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">WhatsApp:</span>
                <span className="font-semibold text-green-600">Active</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Call Service:</span>
                <span className="font-semibold text-green-600">Active</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Services Management */}
        <Card className="bg-white/95 backdrop-blur-sm border-0 p-6 mt-6">
          <h2 className="text-xl font-bold mb-4">Manage Services ({services.length})</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.map((service) => (
              <Card key={service.id} className="p-4 border border-gray-200">
                {editingService?.id === service.id ? (
                  <div className="space-y-3">
                    <Input
                      value={editingService.name}
                      onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                    />
                    <Input
                      value={editingService.emoji}
                      onChange={(e) => setEditingService({ ...editingService, emoji: e.target.value })}
                    />
                    <Select
                      value={editingService.category}
                      onValueChange={(value) => setEditingService({ ...editingService, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex space-x-2">
                      <Button size="sm" onClick={handleUpdateService}>
                        <Save className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditingService(null)}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="text-2xl mb-2">{service.emoji}</div>
                    <h3 className="font-semibold text-sm mb-1">{service.name}</h3>
                    <p className="text-xs text-gray-500 mb-3">{service.category}</p>
                    <div className="flex space-x-1">
                      <Button size="sm" variant="outline" onClick={() => handleEditService(service)}>
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteService(service.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
